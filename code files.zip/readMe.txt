Yahtzee_iteration_1.ipynb - jupyter notebook for iteration 1
Yahtzee_iteration_2.ipynb - jupyter notebook for iteration 2
etc.

resultsSummary_it_1_.csv - summary of results for particular statistics for iteration 1
resultsSummary_it_2_.csv - summary of results for particular statistics for iteration 2
etc.

trial level results are avaialble upon request, but a little large so I did not include